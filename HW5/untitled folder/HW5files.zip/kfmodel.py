import numpy as np

###YOUR CODE HERE###
#motion model
A = np.eye(2) #replace with your A
B = np.eye(2) #replace with your B

#sensor model
C = np.eye(2) #replace with your C
    
#motion noise covariance
R = np.eye(2) #replace with your R

#sensor noise covariance
Q = np.eye(2) #replace with your Q
###YOUR CODE HERE###
